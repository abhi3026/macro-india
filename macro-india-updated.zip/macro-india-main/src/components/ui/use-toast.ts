
// Forward exports from the hooks folder
import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
